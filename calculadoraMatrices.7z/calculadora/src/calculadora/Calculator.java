package calculadora;

public class Calculator {
	
	private Complex num1;
	private Complex num2;
	private ComplexVector vector1;
	private ComplexVector vector2;
	private ComplexArray matriz1;
	private ComplexArray matriz2;
	/**
	 * Constructor de la clase calculadora
	 */
	public Calculator (double a1, double b1, double a2, double b2) {

		this.num1 = new Complex(a1,b1);
		this.num2 = new Complex(a2,b2);
		Complex[][] vectorAux = new Complex[][] {{num1},{num2}};
		
		this.vector1 = new ComplexVector(vectorAux);
		this.vector2 = new ComplexVector(vectorAux);
		
	}
		
	public void suma() {
		System.out.println("Suma: ");
		Complex ans = num1.complexSum(num2);
		System.out.println(ans.numToString());
	}
	
	public void producto() {
		System.out.println("Multiplicacion: ");
		Complex ans4 = num1.multiplicacion(num2);
		System.out.println(ans4.numToString());
	}
	
	public void resta () {
		System.out.println("Resta: ");
		Complex ans2 = num1.resta(num2);
		System.out.println(ans2.numToString());
	}
	
	public void division() {
		System.out.println("Division: ");
		Complex ans5 = num1.division(num2);
		System.out.println(ans5.numToString());
	}
	
	public void modulo() {
		System.out.println("Modulo del primer numero: ");
		double ans6 = num1.modulo();
		System.out.println(ans6);
		
		System.out.println("Modulo del segundo numero: ");
		double ans7 = num2.modulo();
		System.out.println(ans7);
		
	}
	
	public void conjugado() {
		System.out.println("conjugado del primer numero: ");
		Complex ans8 = num1.conjugado();
		System.out.println(ans8.numToString());
		
		System.out.println("Conjugado del segundo numero: ");
		Complex ans9 = num2.conjugado();
		System.out.println(ans9.numToString());
	}
	
	public void polar() {
		System.out.println("Las coordenadas polares del primer numero son: ");
		double[] ans10 = num1.polar();
		System.out.print(ans10[0]);
		System.out.print(",");
		System.out.println(ans10[1]);
		
		System.out.println("Las coordenadas polares del segundo numero son: ");
		double[] ans11 = num2.polar();
		System.out.print(ans11[0]);
		System.out.print(",");
		System.out.println(ans11[1]);
	}
	
	public void cartesiano() {
		
		System.out.println("Las coordenadas cartesianas de la primera coordenada polar es: ");
		Complex ans12= cartesiano(5,30);
		System.out.println(ans12.numToString());
		
		System.out.println("Las coordenadas cartesianas de la segunda coordenada polar es: ");
		Complex ans13= cartesiano(-5,0);
		System.out.println(ans13.numToString());
	}
	
	public void fase () {
		System.out.println("La fase del primer numero es: ");
		double ans14= num1.fase();
		System.out.println(ans14);
		
		System.out.println("La fase del segundo numero es: ");
		double ans15= num2.fase();
		System.out.println(ans15);
	}
	
	/**
	 * Saca la coordenada cartesiana de las coordenadas polares
	 * @return
	 */
	public static Complex cartesiano(double modulo, double angulo) {
		angulo = (double)Math.round(Math.toRadians(angulo) * 100d) / 100d;
		return new Complex((double)Math.round((modulo * (Math.cos(angulo))) * 100d) / 100d,
		(double)Math.round((modulo * (Math.sin(angulo))) * 100d) / 100d);
	}
	
	public void sumaVectores() {
		System.out.println("La suma de entre los dos vectores es:");
		ComplexVector vectorSumado = vector1.sumVector(vector2);
		for (int i = 0; i < vectorSumado.getRow(); i++) {
			for (int j = 0; j < vectorSumado.getColumn(); j++) {
				System.out.println(vectorSumado.getVector()[i][j].numToString());
			}
		}
		
		
	}
	
	public void inversaVectores() {
		
	}
	
	public void productoEscalarVectores() {
		
	}
	
	public void sumaMatrices() {
		
	}
	
	public void inversaMatrices() {
		
	}
	
	public void productoEscalarMatrices() {
		
	}
	
	public void multiplicacionMatrices() {
		
	}
	
	public void matrizTranspuesta() {
		
	}
	
	public void MatrizConjugada() {
		
	}
	
	public void MatrizDaga() {
		
	}
	
	public void accionMatrizSobreVector() {
		
	}
	
	public void normaMatrices() {
		
	}
	
	public void distanciaMatrices() {
		
	}
	
	public void esUnitaria() {
		
	}
	
	public void esHermitiana() {
		
	}
	
	public void productoTensor() {
		
	}
	
	public static void main(String[] args) {
		Calculator calculo1 = new Calculator(-5,4,-6,7);
		calculo1.suma();
		calculo1.producto();
		calculo1.resta();
		calculo1.division();
		calculo1.modulo();
		calculo1.conjugado();
		calculo1.polar();
		calculo1.cartesiano();
		calculo1.sumaVectores();
	}
}