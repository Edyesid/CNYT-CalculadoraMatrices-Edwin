package calculadora;
import static org.junit.Assert.*;
import org.junit.Test;


public class complexTest {
	
	/**
	@Test
	public void deberiaSumar() {

		//assertEquals();
	}
	
	@Test
	public void deberiaRestar() {
		assertEquals();
	}
	
	@Test
	public void deberiaMultiplicar() {
		assertEquals();
	}
	
	@Test
	public void deberiaSacarConjugado() {
		assertEquals();
	}
	
	@Test
	public void deberiaSacarDivision() {
		assertEquals();
	}
	
	@Test
	public void deberiaSacarModulo() {
		assertEquals();
	}
	
	@Test
	public void deberiaSacarAngulo() {
		assertEquals();
	}
	
	@Test
	public void deberiaSacarPolar() {
		assertEquals();
	}
	
	@Test
	public void deberiaSacarCartesiana() {
		assertEquals();
	}
	
	@Test
	public void deberiaSacarFase() {
		assertEquals();
	}
	*/
}