package calculadora;

public class Calculator {
	
	private Complex num1;
	private Complex num2;
	/**
	 * Constructor de la clase calculadora
	 */
	public Calculator (double a1, double b1, double a2, double b2) {

		this.num1 = new Complex(a1,b1);
		this.num2 = new Complex(a2,b2);
		
	}
	
	public Calculator () {
		
	}
		
	public void suma() {
		System.out.println("Suma: ");
		Complex ans = num1.complexSum(num2);
		System.out.println(ans.numToString());
	}
	
	public void producto() {
		System.out.println("Multiplicacion: ");
		Complex ans4 = num1.multiplicacion(num2);
		System.out.println(ans4.numToString());
	}
	
	public void resta () {
		System.out.println("Resta: ");
		Complex ans2 = num1.resta(num2);
		System.out.println(ans2.numToString());
	}
	
	public void division() {
		System.out.println("Division: ");
		Complex ans5 = num1.division(num2);
		System.out.println(ans5.numToString());
	}
	
	public void modulo() {
		System.out.println("Modulo del primer numero: ");
		double ans6 = num1.modulo();
		System.out.println(ans6);
		
		System.out.println("Modulo del segundo numero: ");
		double ans7 = num2.modulo();
		System.out.println(ans7);
		
	}
	
	public void conjugado() {
		System.out.println("conjugado del primer numero: ");
		Complex ans8 = num1.conjugado();
		System.out.println(ans8.numToString());
		
		System.out.println("Conjugado del segundo numero: ");
		Complex ans9 = num2.conjugado();
		System.out.println(ans9.numToString());
	}
	
	public void polar() {
		System.out.println("Las coordenadas polares del primer numero son: ");
		double[] ans10 = num1.polar();
		System.out.print(ans10[0]);
		System.out.print(",");
		System.out.println(ans10[1]);
		
		System.out.println("Las coordenadas polares del segundo numero son: ");
		double[] ans11 = num2.polar();
		System.out.print(ans11[0]);
		System.out.print(",");
		System.out.println(ans11[1]);
	}
	
	public void cartesiano() {
		
		System.out.println("Las coordenadas cartesianas de la primera coordenada polar es: ");
		Complex ans12= cartesiano(5,30);
		System.out.println(ans12.numToString());
		
		System.out.println("Las coordenadas cartesianas de la segunda coordenada polar es: ");
		Complex ans13= cartesiano(-5,0);
		System.out.println(ans13.numToString());
	}
	
	public void fase () {
		System.out.println("La fase del primer numero es: ");
		double ans14= num1.fase();
		System.out.println(ans14);
		
		System.out.println("La fase del segundo numero es: ");
		double ans15= num2.fase();
		System.out.println(ans15);
	}
	
	/**
	 * Saca la coordenada cartesiana de las coordenadas polares
	 * @return
	 */
	public static Complex cartesiano(double modulo, double angulo) {
		
		angulo = (double)Math.round(Math.toRadians(angulo) * 100d) / 100d;
		return new Complex((double)Math.round((modulo * (Math.cos(angulo))) * 100d) / 100d,
		(double)Math.round((modulo * (Math.sin(angulo))) * 100d) / 100d);
	}
	/**
	 * Saca la suma de dos vectores
	 */
	public void sumaVectores() {
		
		Complex num1 = new Complex(8,3);
		Complex num2 = new Complex(-1,-4);
		Complex num3 = new Complex(0,-9);
		
		Complex num4 = new Complex(8,-3);
		Complex num5 = new Complex(2,5);
		Complex num6 = new Complex(3,0);
		
		Complex[][] vectorAux = new Complex[][] {{num1},{num2},{num3}};
		Complex[][] vectorAux2 = new Complex[][] {{num4},{num5},{num6}};
		
		ComplexVector vector1 = new ComplexVector(vectorAux);
		ComplexVector vector2 = new ComplexVector(vectorAux2);
		
		System.out.println("La suma de entre los dos vectores es:");
		
		ComplexVector vectorSumado = vector1.sumVector(vector2);
		
		vectorSumado.printVector();
	}
	
	public void inversaVectores() {
		
		System.out.println("La inversa del vector es: ");
		
		Complex num1 = new Complex(-5,2);
		Complex num2 = new Complex(3,0);
		Complex num3 = new Complex(0,-1);
		
		Complex[][] vectorAux = new Complex[][] {{num1},{num2},{num3}};
		
		ComplexVector vector1 = new ComplexVector(vectorAux);
		
		ComplexVector ans = vector1.VectorInverso();
		
		ans.printVector();
		
	}
	
	public void productoEscalarVectores() {
		
		System.out.println("El producto escalar del vector es: ");
		
		Complex num1 = new Complex(-2,5);
		Complex num2 = new Complex(-1,-1);
		Complex num3 = new Complex(2,-9);
		
		Complex[][] vector = new Complex[][] {{num1},{num2},{num3}};
		
		ComplexVector vector1 = new ComplexVector(vector);
		
		Complex num4 = new Complex(-1,1);
		
		ComplexVector ans = vector1.vectorEscalar(num4);
		
		ans.printVector();
		
	}
	
	public void sumaMatrices() {
		
		System.out.println("La suma de matrices es: ");
		
		Complex num1 = new Complex(-8,-3);
		Complex num2 = new Complex(-6,-4);
		Complex num3 = new Complex(0,-4);
		Complex num4 = new Complex(-1,8);
		Complex num5 = new Complex(6,-10);
		Complex num6 = new Complex(8,-5);
		Complex num7 = new Complex(4,0);
		Complex num8 = new Complex(8,5);
		Complex num9 = new Complex(-7,-9);
		
		Complex[][] matrizAux = new Complex[][] {{num1,num2,num3},{num4,num5,num6},{num7,num8,num9}};
		ComplexArray matriz1 = new ComplexArray(matrizAux);
		
		Complex num1d = new Complex(-7,-2);
		Complex num2d = new Complex(-4,-2);
		Complex num3d = new Complex(7,7);
		Complex num4d = new Complex(5,9);
		Complex num5d = new Complex(0,3);
		Complex num6d = new Complex(6,-5);
		Complex num7d = new Complex(1,5);
		Complex num8d = new Complex(-6,-6);
		Complex num9d = new Complex(5,8);
		
		Complex[][] matrizAux2 = new Complex[][] {{num1d,num2d,num3d},{num4d,num5d,num6d},{num7d,num8d,num9d}};
		ComplexArray matriz2 = new ComplexArray(matrizAux2);
		
		ComplexArray ans = matriz1.sumArray(matriz2);
		
		ans.printArray();
	}
	
	public void inversaMatrices() {
		
		System.out.println("La inversa de la matriz es: ");
		
		Complex num1 = new Complex(7,3);
		Complex num2 = new Complex(-1,7);
		Complex num3 = new Complex(-9,-4);
		Complex num4 = new Complex(-7,-9);
		
		Complex[][] matrizAux2 = new Complex[][] {{num1,num2,},{num3,num4}};
		ComplexArray matriz2 = new ComplexArray(matrizAux2);
		
		ComplexArray ans = matriz2.arrayInverse();
		
		ans.printArray();
		
	}
	
	public void productoEscalarMatrices() {
		
		System.out.println("El producto escalar de la matriz es: ");
		
		Complex num1 = new Complex(3,-2);
		Complex num2 = new Complex(8,-4);
		Complex num3 = new Complex(4,-10);
		Complex num4 = new Complex(-2,-8);
		
		Complex[][] matrizAux2 = new Complex[][] {{num1,num2,},{num3,num4}};
		ComplexArray matriz2 = new ComplexArray(matrizAux2);
		
		Complex num = new Complex(-2,3);
		
		ComplexArray ans = matriz2.vectorEscalar(num);
		
		ans.printArray();
		
	}
	
	public void multiplicacionMatrices() {
		
		System.out.println("La multiplicacion de matrices es: ");
		
		Complex num1 = new Complex(-6,2);
		Complex num2 = new Complex(0,6);
		Complex num3 = new Complex(7,2);
		Complex num4 = new Complex(6,9);
		Complex num5 = new Complex(7,7);
		Complex num6 = new Complex(-6,-6);
		Complex num7 = new Complex(5,8);
		Complex num8 = new Complex(-6,8);
		Complex num9 = new Complex(6,9);
		
		Complex[][] matrizAux = new Complex[][] {{num1,num2,num3},{num4,num5,num6},{num7,num8,num9}};
		ComplexArray matriz1 = new ComplexArray(matrizAux);
		
		Complex num1d = new Complex(9,-6);
		Complex num2d = new Complex(-3,-4);
		Complex num3d = new Complex(5,-2);
		Complex num4d = new Complex(3,6);
		Complex num5d = new Complex(-1,-5);
		Complex num6d = new Complex(0,-5);
		Complex num7d = new Complex(9,9);
		Complex num8d = new Complex(8,-4);
		Complex num9d = new Complex(-8,-4);
		
		Complex[][] matrizAux2 = new Complex[][] {{num1d,num2d,num3d},{num4d,num5d,num6d},{num7d,num8d,num9d}};
		ComplexArray matriz2 = new ComplexArray(matrizAux2);
		
		ComplexArray ans = matriz1.arrayProduto(matriz2);
		
		ans.printArray();
		
	}
	
	public void matrizTranspuesta() {
		
		System.out.println("La matriz transpuesta es: ");
		
		Complex num1 = new Complex(5,9);
		Complex num2 = new Complex(-7,-5);
		Complex num3 = new Complex(-1,-4);
		Complex num4 = new Complex(8,2);
		Complex num5 = new Complex(-3,-7);
		Complex num6 = new Complex(7,-8);
		
		Complex[][] matrizAux = new Complex[][] {{num1,num2,num3},{num4,num5,num6}};
		ComplexArray matriz2 = new ComplexArray(matrizAux);
		
		ComplexArray ans = matriz2.transpuesta();
		
		ans.printArray();
		
	}
	
	public void MatrizConjugada() {
		
		System.out.println("La matriz conjugada es: ");
		
		Complex num1 = new Complex(-6,1);
		Complex num2 = new Complex(3,8);
		Complex num3 = new Complex(2,-6);
		Complex num4 = new Complex(3,0);
		
		Complex[][] matrizAux = new Complex[][] {{num1,num2},{num3,num4}};
		ComplexArray matriz = new ComplexArray(matrizAux);
		
		ComplexArray ans = matriz.arrayConjugado();
		
		ans.printArray();
		
	}
	
	public void MatrizDaga() {
		
		System.out.println("La matriz adjunta(daga) es: ");
		
		Complex num1 = new Complex(7,7);
		Complex num2 = new Complex(3,8);
		Complex num3 = new Complex(8,4);
		Complex num4 = new Complex(5,0);
		Complex num5 = new Complex(8,-6);
		Complex num6 = new Complex(-10,-1);
		
		Complex[][] matrizAux = new Complex[][] {{num1,num2,num3},{num4,num5,num6}};
		ComplexArray matriz = new ComplexArray(matrizAux);
		
		ComplexArray ans = matriz.arrayAdjunta();
		
		ans.printArray();
		
	}
	
	public void productoInternoDeVectores() {
		
		System.out.println("El producto interno de vectores es: ");
		
		Complex num1 = new Complex(2,-1);
		Complex num2 = new Complex(-8,-5);
		Complex num3 = new Complex(-2,-6);
		
		Complex num4 = new Complex(6,-3);
		Complex num5 = new Complex(5,-1);
		Complex num6 = new Complex(-6,-2);
		
		Complex[][] vectorAux = new Complex[][] {{num1},{num2},{num3}};
		Complex[][] vectorAux2 = new Complex[][] {{num4},{num5},{num6}};
		
		ComplexVector vector1 = new ComplexVector(vectorAux);
		ComplexVector vector2 = new ComplexVector(vectorAux2);
		
		Complex ans = vector1.produtoInternoDeVectores(vector2);
		
		System.out.println(ans.numToString());
		
	}
	
	public void accionMatrizSobreVector() {
		
		
	}
	
	public void normaMatrices() {
		
	}
	
	public void distanciaMatrices() {
		
	}
	
	public void esUnitaria() {
		
	}
	
	public void esHermitiana() {
		
	}
	
	public void productoTensor() {
		
	}
	
	public static void main(String[] args) {
		Calculator calculo1 = new Calculator(-5,4,-6,7);
		calculo1.suma();
		calculo1.producto();
		calculo1.resta();
		calculo1.division();
		calculo1.modulo();
		calculo1.conjugado();
		calculo1.polar();
		calculo1.cartesiano();
		Calculator calculo2 = new Calculator();
		calculo2.sumaVectores();
		calculo2.inversaVectores();
		calculo2.productoEscalarVectores();
		calculo2.sumaMatrices();
		calculo2.inversaMatrices();
		calculo2.productoEscalarMatrices();
		calculo2.multiplicacionMatrices();
		calculo2.matrizTranspuesta();
		calculo2.MatrizConjugada();
		calculo2.MatrizDaga();
		calculo2.productoInternoDeVectores();
	}
}