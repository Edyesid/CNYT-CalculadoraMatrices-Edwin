package calculadora;
import javax.swing.JOptionPane;

public class ComplexVector {
	private int row;
	private int column;
	private Complex[][] vector;
	
	public ComplexVector(Complex[][] vector) {
		
		if(vector[0].length > 1) {
			JOptionPane.showMessageDialog(null, "El numero de columnas es mayor que uno");
			return;
		}
		this.vector = vector;
		this.row = vector.length;
		this.column = 1;
	}

	/**
	 * Hace la suma de dos vectores
	 * @param arrayB es y la matriz y o vector
	 * @return la matriz resultante de la suma
	 */
	public ComplexVector sumVector(ComplexVector vectorB) {
		
		Complex[][] vectorSuma = new Complex[row][column];
		Complex[][] vector2 = vectorB.vector;
		
		if (row != vectorB.row) {
			JOptionPane.showMessageDialog(null, "El numero de filas no es igual");
			return null;
		} else if(column > 1 || vectorB.column > 1) {
			JOptionPane.showMessageDialog(null, "El numero de columnas es mayor que uno");
			return null;
		}
		
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				vectorSuma[i][j] = vector[i][j].complexSum(vector2[i][j]);
			}
		}
		return new ComplexVector(vectorSuma);
		
	}
	/**
	 * Muestra la inversa del vector
	 * @return El vector inverso
	 */
	public ComplexVector VectorInverso() {
		
		Complex[][] vectorInverso = new Complex[row][column];
		
		for (int i = 0; i < row; i++) {
			for (int j = 0; i < column; j++) {
				vectorInverso[i][j] = vector[i][j].inverso();
			}
		}
		return new ComplexVector(vectorInverso);
	}
	/**
	 * multiplica un escalar por un vector
	 * @param escalar
	 * @return el vector resultante
	 */
	public ComplexVector vectorEscalar(Complex escalar) {
		
		Complex[][] vectorEscalar = new Complex[row][column];
		
		for (int i = 0; i < row; i++) {
			for (int j = 0; i < column; j++) {
				vectorEscalar[i][j] = vector[i][j].multiplicacion(escalar);
			}
		}
		return new ComplexVector(vectorEscalar);
	}
	
	public Complex produtoInternoDeVectores(ComplexVector vectorB) {
		
		if (row != vectorB.row || column != vectorB.column) {
			JOptionPane.showMessageDialog(null, "Los vectores deben ser iguales");
			return null;
		}
	}
}




