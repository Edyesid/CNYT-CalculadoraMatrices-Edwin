package calculadora;
import java.util.Scanner;

public class Calculator {
	
	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		System.out.println("ingrese a1");
		double a1 = reader.nextInt();
		System.out.println("ingrese b1");
		double b1 = reader.nextInt();
		System.out.println("ingrese a2");
		double a2 = reader.nextInt();
		System.out.println("ingrese b2");
		double b2 = reader.nextInt();
		
		Complex num1 = new Complex(a1,b1);
		Complex num2 = new Complex(a2,b2);
		
		System.out.println("Suma:");
		Complex ans = num1.complexSum(num2);
		System.out.println(ans.numToString());
		
		System.out.println("Resta:");
		Complex ans2 = num1.resta(num2);
		System.out.println(ans2.numToString());
		
		System.out.println("Resta:");
		Complex ans3 = num1.resta(num2);
		System.out.println(ans3.numToString());
		
		System.out.println("Multiplicacion:");
		Complex ans4 = num1.multiplicacion(num2);
		System.out.println(ans4.numToString());
		
		System.out.println("Division:");
		Complex ans5 = num1.division(num2);
		System.out.println(ans5.numToString());
	}
}